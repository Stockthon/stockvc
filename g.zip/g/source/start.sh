echo "The source was developed by Ahmed Ayad"
sleep 10
echo "install pyrogram"
#pip3 install pyrogram==1.2.20
pip3 install pyrogram
echo "pyrogram installd"
echo "install py-tgcalls"
pip3 install py-tgcalls
echo "py-tgcalls installd"
echo "install yt-dlp"
pip3 install git+https://github.com/yt-dlp/yt-dlp@master
echo "yt-dlp installd"
echo "run bot"
python3 main.py
